# gpustack-operator

A Kubernetes operator that turns raw node hardware into a Kueue-based scheduling chain for accelerators (GPU/NPU/TPU), built on Node Feature Discovery (NFD) and Kueue.

## Introduction

This chart deploys the GPUStack Operator control plane (`gpustack-operator-worker`), the
per-manufacturer device managers (`gpustack-operator-device-manager-<manufacturer>`), and the
applications the scheduling chain is built on — [Kueue](https://kueue.sigs.k8s.io),
[Node Feature Discovery](https://kubernetes-sigs.github.io/node-feature-discovery) and the NFS/S3
CSI drivers — onto a Kubernetes cluster using the [Helm](https://helm.sh) package manager.

The operator turns raw node hardware into a Kueue-based scheduling chain for accelerators
(GPU/NPU/TPU).

> Those four applications are **vendored subcharts** of this chart, each behind an `enabled` switch,
> and they are deployed as part of **this** release. Two consequences worth knowing before you
> install:
>
> - `helm uninstall` deletes Kueue's CRDs, and therefore **every ClusterQueue, LocalQueue,
>   ResourceFlavor, AdmissionCheck and Workload in the cluster**. To keep a Kueue this release does
>   not own, install with `--set kueue.enabled=false` and bring your own. The same applies to
>   `node-feature-discovery.enabled=false`, which still gives you the `gpustack-cpu-info`
>   NodeFeatureRule the chain starts from.
> - Upgrading an install from v0.7.x or earlier, where these ran as Helm releases of their own, is a
>   **one-time ownership transfer**. See the
>   [migration guide](https://github.com/gpustack/gpustack-operator/blob/main/docs/operate/migration/bundled-subcharts.md).

Running more than one replica of each control-plane component is described in the
[high-availability guide](https://github.com/gpustack/gpustack-operator/blob/main/docs/operate/high-availability.md).

## Prerequisites

Kubernetes: `>=1.23.0-0`
- Kubernetes 1.29+ for the Kueue scheduling chain the bundled Kueue v0.18 requires; `1.23` is the install floor, and what works from `1.23` to `1.28` is not verified by any test
- Helm 3.8.0+ — or **3.21.0+** for the one-time upgrade of a v0.7.x-or-earlier install, which needs `--take-ownership`
- (Optional) [cert-manager](https://cert-manager.io) when `global.certmanager.enabled` is `"true"` (or `"auto"` with cert-manager present); it then issues every serving certificate this release needs, the bundled Kueue's included

## Installing the Chart

To install the chart with the release name `gpustack-operator`:

```bash
helm repo add gpustack https://docs.gpustack.ai/gpustack-operator/charts
helm install gpustack-operator gpustack/gpustack-operator \
  --namespace gpustack-system \
  --create-namespace
```

> Install with the release name `gpustack-operator` so that the rendered resource names
> match the conventional `gpustack-operator-worker` / `gpustack-operator-device-manager`.

## Upgrading the Chart

Upgrade with `--reset-then-reuse-values` (Helm 3.14+):

```bash
helm upgrade gpustack-operator gpustack/gpustack-operator \
  --namespace gpustack-system \
  --reset-then-reuse-values
```

It keeps the values you have set, at install and on every upgrade since, and takes every other value
from the new chart. `--reuse-values` does not: it carries the release's computed values forward, the
old chart's defaults included, so a default the new chart changes never reaches the release. A release
already upgraded that way picks the new defaults up on its next `--reset-then-reuse-values` upgrade.
A plain `--values`/`--set` upgrade takes the new defaults too, but drops every value it does not repeat.

With a Helm older than 3.14, hand your values back yourself, without any reuse flag:

```bash
helm get values gpustack-operator --namespace gpustack-system --output yaml > prev.yaml
helm upgrade gpustack-operator gpustack/gpustack-operator \
  --namespace gpustack-system \
  --values prev.yaml
```

## Uninstalling the Chart

To uninstall the `gpustack-operator` release:

```bash
helm uninstall gpustack-operator --namespace gpustack-system
```

`helm uninstall` removes only what the release owns. The finalizers the controllers leave on their
objects, and the CRDs, aggregated APIServices and webhook configurations the worker registers itself,
stay behind. Run the chart's `files/cleanup.sh` afterwards to clear them, or install with
`--set cleanupOnUninstall=true` to have gated hook Jobs do it — which is safe only where this release
exclusively owns those CRDs. Before anything is deleted, those Jobs drain the operator's custom
resources and, where this release owns Kueue, stop the worker and delete the Kueue objects it created
while Kueue can still finalize them; the post-delete Job then clears what is left.
On the Nodes, the cleanup deletes the NodeFeatures the operator reported and removes the
`topology.gpustack.ai/profile`, `sliced-max-free-units.fit.gpustack.ai/*` and
`shared-free-cards.fit.gpustack.ai/*` labels the worker wrote; it leaves
`gpustack.ai/managed` and the other `topology.gpustack.ai/*` labels, which an administrator may set.

The dependencies listed below are **vendored subcharts**: their sources are committed into this
chart's `charts/` directory, so the `Repository` column is intentionally empty — `helm install`
fetches nothing beyond the chart itself. Each is pinned at the version shown and sits behind its own
`<name>.enabled` switch (`kueue`, `node-feature-discovery`, `csi-driver-nfs`, `csi-driver-s3`).

## Requirements

Kubernetes: `>=1.23.0-0`

| Repository | Name | Version |
|------------|------|---------|
|  | csi-driver-nfs | 4.13.4 |
|  | csi-driver-s3 | 0.43.7 |
|  | kueue | 0.18.11 |
|  | node-feature-discovery | 0.19.0 |
|  | topograph | 1.0.0 |

## Remote weight delivery

By default, a `ModelDeployment`'s weights reach the engine the way they always
have — the node's model-manager plugin materializes them on the node's cache
(`modelManager`, Node delivery) or the engine downloads them itself (Engine
delivery) — unless a `ModelPrefetch` in the same namespace prepares a host-memory
source. The source runtime (`modelTransfer.enabled=true`) is deployed by default
on accelerator nodes, and the worker's built-in
`model-artifact-remote-delivery-policy` `Setting` defaults to `Prefer` (editable
at runtime to `Disabled`, `Require`, or `Prefer`):

1. `modelTransfer.enabled=true` (default) ships the source runtime's identity: a
   ServiceAccount whose RBAC is what a source broker runs under (TokenReview to
   admit a session's bearer token, the read side of the prefetch, artifact,
   binding, store, instance-type, pool and settings surface the shared
   eligibility check resolves against, the Binding's initial annotation, and a
   Role scoped to the operator namespace's ConfigMaps where the Binding-wide
   reservation authority lives — no devices, no cache paths, no tenant secrets).
   While enabled, no `GPUSTACK_MODEL_ARTIFACT_REMOTE_DELIVERY_POLICY` variable
   is rendered on the worker, so the `Setting` remains editable at runtime.
   Setting `modelTransfer.enabled=false` omits the source runtime and declares
   `GPUSTACK_MODEL_ARTIFACT_REMOTE_DELIVERY_POLICY=Disabled` on the worker.
2. `modelTransfer.images` turns the source runtime on, one DaemonSet per named
   manufacturer, each Pod carrying two containers: the operator image runs the
   `model-transfer` broker (its engine session listener on :9251 is TLS only,
   its worker control wire stays on the Pod's loopback at 127.0.0.1:9250), and
   the named vendor image runs the `gpustack_model_transfer.source` module. The
   broker keeps its durable ledger per vendor under `/var/lib/gpustack/model-transfer`,
   which the model-manager plugin mounts read-only when remote delivery is on to
   report the ModelTransfer status; both containers see the node's model cache,
   writable for the broker, read-only for the worker; the two share the Pod-local
   bootstrap credential and nothing else. The universal
   `gpustack_model_transfer` wheel a remote replica's engine installs is staged
   on every node by the source DaemonSet
   (`pack/model-transfer/Dockerfile` stages it under `/etc/gpustack/lib/model-transfer`;
   the `stage-libs` initContainer copies it to `/var/lib/gpustack/operator/lib/model-transfer`).

The default `modelTransfer.images` references cover NVIDIA, AMD and Ascend A5.
Override the full references when selecting a different qualified runtime:

```yaml
modelTransfer:
  enabled: true
  source:
    maxMemoryBytes: 26843545600 # 25 GiB; 0 follows the node's total RAM (one sixteenth)
    minMemoryBytes: 1073741824  # 1 GiB, the smallest buffer the node still serves
    maxSessions: 64             # the node's concurrent source-session cap
  env:
    GPUSTACK_MODEL_TRANSFER_HIXL_RESIDENT_BUDGET_BYTES: "17179869184"
  images:
    nvidia: gpustack/model-transfer:v0.1.0-cuda12.9
    amd: gpustack/model-transfer:v0.1.0-rocm7.2
    ascend: gpustack/model-transfer:v0.1.0-cann9.2-a5
```

`global.imageRegistry` (or `global.hub`) and `global.imageNamespace` rewrite the
registry and namespace segments of these references when set, while keeping each
entry's own tag intact. Missing entries ship no source
runtime for that manufacturer. Helm merges map overrides with the defaults; set
`modelTransfer.images.<manufacturer>: null` to remove a default entry. Each DaemonSet schedules only on nodes NFD
labelled with the manufacturer's PCI vendor, merged under whatever
`global.nodeSelector` and `modelTransfer.nodeSelector` state; a NVIDIA source
worker runs under its RuntimeClass so the container runtime injects the driver.
All configured vendors run privileged workers with host `/dev` and `/sys` access, including
InfiniBand/RoCE devices. Ascend mounts the host's driver and DCMI libraries separately,
leaving the image's own CANN in place. `modelTransfer.source` carries the node's
memory window and session policy. `maxMemoryBytes` is the transfer buffer
ceiling: `0` (the default) follows the node's total RAM — one sixteenth of it,
floored at `minMemoryBytes` — and a positive figure below `minMemoryBytes`
silently resolves up to it. `minMemoryBytes` defaults to `1 GiB`; lower values
resolve to `1 GiB`. `maxSessions` caps concurrent source sessions in the
DaemonSet Pod; zero resolves to `64`. Chart validation rejects negative values.
`workerResources` is empty by default and renders no `resources` block, so both
the broker and the worker size the transfer buffer against the node's RAM via
`/proc/meminfo` without a container cgroup memory cap; set explicit resources
only when you want Kubernetes resource bounds on the worker container. Disk warm-up keeps its separate
Python Alpine image. Host driver versions do not select images; runtime
compatibility remains required.

`ModelStoreBinding.spec.sourceMemory` is an optional, namespace-wide grant.
When it is omitted or removed, source prefetches use the node ceiling, `4096`
registrations and the node session cap. An administrator can set the grant to
cap a Binding below the node ceiling. Its bytes and registrations can only grow
while present; sessions can change online, and admitted sessions above a lowered
cap drain naturally.

For each generation, the broker reserves the full checkpoint size plus 10%
against the effective grant and the node ceiling. The source worker allocates every
registered file. Leave space for other live and retained generations and for
worker runtime memory.

When the Binding has a source-memory grant, the controller checks a planned
source window against it. Without a grant, it skips this check. It deducts a
`1 GiB` fill window and `256 MiB` runtime overhead, then sets aside one quarter
of residency for quarantine. The maximum is
`((grantBytes - 1.25 GiB) / 5) * 4`, with integer division in bytes. A `25Gi`
grant backs a planned `19 GiB` window: a `15 GiB` checkpoint fits fully, while a
`67 GiB` checkpoint is clamped in the plan. The plan is currently only a floor
check. The broker still requests `73.7 GiB` for the larger checkpoint and
refuses the `25Gi` grant; the worker does not have a bounded host-memory sliding
window.

The controller's planned-source-window floor is fixed at `1 GiB` and no longer
reads an environment figure. Below this floor, `Prefer` reports
`SourceWindowFallback` and `Require` reports `SourceWindowBelowFloor`. The
floor applies to the grant's capacity, not the checkpoint size.
`modelTransfer.env` applies to the source broker and worker, not the
controller or serving engine. Its HIXL budget defaults to `16 GiB` and
controls registration paging, not host allocations; one file can exceed it.
A nonzero value below `1 GiB` silently resolves up to `1 GiB`; zero uses the
default.
`GPUSTACK_MODEL_TRANSFER_MAX_WINDOW_BYTES` defaults to `8 GiB` for the engine
reader. Set it on the engine, not in `modelTransfer.env`; it accepts `1 GiB`
through `1 TiB` — a value below `1 GiB` silently resolves up to `1 GiB`, and
`16 GiB`, `64 GiB`, `128 GiB` are all legal — and does not change the source
grant. When available RAM backs a source window, the broker reports it as
`sourceWindowBytes`. The reader clamps its session window to the smaller budget,
with a `256 MiB` adaptive floor, and transfers larger spans in chunks. The
broker omits the figure when available RAM is unreadable or cannot clear the
floor. The engine's `GPUSTACK_MODEL_TRANSFER_TP_MODE` variable also belongs on
the serving role, not in `modelTransfer.env`. See
[Remote Weight Delivery](../../../docs/modules/model-delivery/remote.md#replica-startup)
for its modes and window sizing.

Before initial allocation, the worker checks available RAM when its maximum is
configured and the RAM figure is readable. A zero maximum derives one sixteenth
of total RAM, floored at the minimum. The worker skips the check if the maximum
is unset or available RAM is unreadable. After active sessions drain, it releases
idle blocks when no native operations or unknown sessions remain. A later session
rebuilds them from the verified node cache. `Prefer` can fall back to local or
peer delivery when source preparation fails; `Require` waits. See
[Remote Weight Delivery](../../../docs/modules/model-delivery/remote.md#source-preparation)
for dynamic sizing and troubleshooting.

Every broker's session listener serves TLS under a per-manufacturer certificate
the chart provisions — via cert-manager when `global.certmanager.enabled`
resolves to it, otherwise a chart-generated pair kept across upgrades — issued
for the manufacturer's headless Service DNS name, whose endpoints an engine
resolves to pick one source Pod rather than a random backend. The public CA
half lands in the `<release>-model-transfer-<manufacturer>-cert` Secret beside
the serving pair; the worker's renderer mirrors it into the namespaces that
consume it, since a cross-namespace Secret cannot be mounted directly.

When an existing image reference in `modelTransfer.images` changes on `helm upgrade`,
the DaemonSet uses `OnDelete` so the controller drains source Pods before replacing them.
Removing a manufacturer entry or disabling the source runtime lets Helm delete the
corresponding DaemonSet directly, without waiting for that drain acknowledgement.
Perform this maintenance when the affected workload is stable.

Rolling back is turning the policy back: patch the
`model-artifact-remote-delivery-policy` `Setting` to `Disabled` (or set
`modelTransfer.enabled=false` in values). Replicas already loaded keep serving;
new replicas are admitted on the base delivery mode, and no destination
checkpoint a Require deployment refused to materialize was ever written.

## Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| cleanupOnUninstall | bool | `false` | Run a post-delete cleanup Job on `helm uninstall` that removes the leftovers the worker creates at runtime but Helm does not manage: the Kueue / Node Feature Discovery / CSI Helm releases, the finalizers pinning Kueue and Instance objects, and the aggregated APIServices / webhooks. Of the CRDs it removes this chart's own and the Kueue ones this release installed; Node Feature Discovery's are LEFT IN PLACE, because its subchart ships them in a way that records no Helm ownership and deleting them would be a guess with a cluster-wide blast radius. Disabled by default because the CRDs it does remove may be shared with other workloads; enable only when this release exclusively owns them (e.g. CI / e2e). |
| cleanupDrainBudgetSeconds | int | `210` | Seconds the pre-delete drain spends waiting for this operator's custom resources to finish deleting, so each finalizer's teardown runs while its controller is still up (a KVCacheBackend empties every node's cache tier; a KVCachePoolBinding drops its tenant from the cache master's quota ledger). The Job's own deadline is derived from this, so RAISING IT ALONE IS NOT ENOUGH: helm waits on a delete hook for `--timeout` (5m by default) and then fails the uninstall, so a larger budget needs a larger `--timeout` beside it. The default is sized to fit inside the default `--timeout`. Whatever has not drained by then is reported, and the post-delete cleanup removes it by force. The floor of 1 is enforced by the schema because a zero or negative budget makes the drain a no-op that still reports success - the silent skip this whole phase exists to prevent. |
| ledgerReleaseTerminatedPods | bool | `true` | Whether the accelerator ledger stops charging a Pod that has finished (phase Succeeded or Failed) for the exclusive cards, shared cards and logical slices kubelet has taken back from it. A hardware partition, and a MetaX or Cambricon slice, stay charged until the Pod object is gone, because they are destroyed only then. Set it to false to charge every finished Pod until its object is gone, as before; the sliced Allocate gate then charges it too, which it did not do before. Rendered as GPUSTACK_LEDGER_RELEASE_TERMINATED_PODS on the worker, whose node-devices check rebuilds the ledger, and on every device-manager, which publishes it. |
| global | object | `{"certmanager":{"enabled":"auto","issuer":{"kind":"Issuer","name":""}},"hub":"","imageNamespace":"","imagePullPolicy":"","imagePullSecrets":[],"imageRegistry":"","manufacturers":{"amd":{"pciVendorID":"1002","resourceName":"amd.com/gpu","runtimeName":"amd"},"ascend":{"pciVendorID":"19e5","resourceName":"huawei.com/npu","runtimeInjectsDevices":true,"runtimeName":"ascend"},"cambricon":{"pciVendorID":"cabc","resourceName":"cambricon.com/mlu","runtimeName":"cambricon"},"hygon":{"partitionKind":"mig","pciVendorID":"1d94","resourceName":"hygon.com/dcu"},"iluvatar":{"pciVendorID":"1e3e","resourceName":"iluvatar.com/gpu","runtimeInjectsDevices":true,"runtimeName":"iluvatar"},"metax":{"pciVendorID":"9999","resourceName":"metax-tech.com/gpu"},"mthreads":{"pciVendorID":"1ed5","resourceName":"mthreads.com/gpu","runtimeInjectsDriver":true,"runtimeName":"mthreads"},"nvidia":{"partitionKind":"mig","pciVendorID":"10de","resourceName":"nvidia.com/gpu","runtimeInjectsDriver":true,"runtimeName":"nvidia"},"thead":{"partitionKind":"mig","pciVendorID":"1ded","resourceName":"alibabacloud.com/ppu"}},"nodeSelector":{}}` | Global values shared across the chart and its subcharts. |
| global.imageRegistry | string | `""` | Image registry override applied to every image this chart renders, the subcharts' workloads, sidecars and hook Jobs included (e.g. "docker.io"). When empty, `global.hub` is consulted next — an alias for umbrella charts that also carry Istio-derived subcharts, which read `hub` and will keep doing so upstream, so one value can mirror every image instead of two that have to be kept equal. When both are empty, the registry each image reference already encodes is used as-is. |
| global.hub | string | `""` | Alias for `imageRegistry`, consulted only when that is empty. Present so an umbrella chart can set a single registry value for Istio-derived subcharts and this one alike. |
| global.imageNamespace | string | `""` | Image namespace override applied to every image this chart renders, the subcharts' workloads, sidecars and hook Jobs included. When non-empty it replaces the namespace segment of each image reference (e.g. "gpustack"). |
| global.imagePullPolicy | string | `""` | Image pull policy applied to every workload, the subcharts' included. It outranks a component's own pull policy; when empty, each component's own is used. |
| global.imagePullSecrets | list | `[]` | Image pull secrets applied to all workloads. |
| global.nodeSelector | object | `{}` | Node selector applied to every long-running workload this release deploys, when the component sets none of its own: the worker, the device managers, and the subcharts' control planes — Kueue's manager and its optional KueueViz, NFD's master and gc, the CSI controllers. A component-level `nodeSelector`, when non-empty, REPLACES this value entirely (no merging); the device managers and the CSI controllers merge it instead, since their own selectors state a requirement (a manufacturer's PCI vendor, an OS) rather than a placement.  Two sets of workloads are deliberately left out.  The ones that have to cover the nodes they serve: NFD's worker and topology updater, and the CSI node plugins. Confining NFD's worker would leave every node outside the selector unlabelled — including the `feature.node.kubernetes.io/pci-*.present` labels the device managers and a GPUStack worker select on — so a selector meant to confine this release would end up scheduling nothing at all.  And the hook Jobs, which Helm runs outside the window where this release's workloads exist: before they are created, and after they are gone. A selector naming a label the release itself produces would leave the pre-install hook Pending with nothing able to satisfy it, because the workload that applies the label is in the manifest that hook gates. An NFD label is the obvious way to write "only GPU nodes" and would deadlock a fresh install, so the hooks stay schedulable wherever the cluster will take them. |
| global.certmanager | object | `{"enabled":"auto","issuer":{"kind":"Issuer","name":""}}` | Configure cert-manager integration for every serving certificate this release needs: the worker's webhook certificate and Kueue's. It lives under `global` because Kueue is a vendored subchart and `global` is the only channel Helm gives a subchart to this chart's values. Each component used to be switched on its own, so a cluster with cert-manager installed issued the worker's certificate through it while Kueue went on self-signing — two answers to one question, and the detection behind `auto` could never reach Kueue at all. |
| global.certmanager.enabled | string | `"auto"` | Whether to issue the serving certificates with cert-manager. Accepts a string (or the equivalent boolean): "auto" creates the cert-manager resources only when the cert-manager CRDs are detected in the cluster; "true" always creates them (cert-manager must be installed); "false" never creates them and each component generates and manages its own certificate.  Turning it ON later is a plain `helm upgrade`. Turning it OFF again is not: cert-manager owns the Secret Kueue's chart wants to template and writes CA bundles Helm never recorded, so `helm upgrade` refuses the Secret before it starts, and forcing past that fails mid-apply on the visibility APIServices. docs/operate/migration/bundled-subcharts.md carries the sequence that does work. The same applies when cert-manager is uninstalled from a cluster while this is "auto", which flips the answer without anyone editing a value. |
| global.certmanager.issuer.name | string | `""` | Existing issuer name to use; when empty a self-signed Issuer is created per component. |
| global.certmanager.issuer.kind | string | `"Issuer"` | Issuer kind ("Issuer" or "ClusterIssuer"); only used when `issuer.name` is set. |
| global.manufacturers | object | `{"amd":{"pciVendorID":"1002","resourceName":"amd.com/gpu","runtimeName":"amd"},"ascend":{"pciVendorID":"19e5","resourceName":"huawei.com/npu","runtimeInjectsDevices":true,"runtimeName":"ascend"},"cambricon":{"pciVendorID":"cabc","resourceName":"cambricon.com/mlu","runtimeName":"cambricon"},"hygon":{"partitionKind":"mig","pciVendorID":"1d94","resourceName":"hygon.com/dcu"},"iluvatar":{"pciVendorID":"1e3e","resourceName":"iluvatar.com/gpu","runtimeInjectsDevices":true,"runtimeName":"iluvatar"},"metax":{"pciVendorID":"9999","resourceName":"metax-tech.com/gpu"},"mthreads":{"pciVendorID":"1ed5","resourceName":"mthreads.com/gpu","runtimeInjectsDriver":true,"runtimeName":"mthreads"},"nvidia":{"partitionKind":"mig","pciVendorID":"10de","resourceName":"nvidia.com/gpu","runtimeInjectsDriver":true,"runtimeName":"nvidia"},"thead":{"partitionKind":"mig","pciVendorID":"1ded","resourceName":"alibabacloud.com/ppu"}}` | Accelerator manufacturers to manage, one row per manufacturer holding everything the release needs to know about it. `pciVendorID` is what NFD labels its devices with, `resourceName` what its device-plugin advertises to the kubelet, `runtimeName` the RuntimeClass its workloads run under, and `partitionKind` its own name for hardware partitioning ("mig" is NVIDIA's name for the concept, not the concept's). Each of those four is also a `pkg/nodefeature` default overridable by a `GPUSTACK_<MANUFACTURER>_*` variable, and this chart fans every stated one out as that variable to the worker and to the device-managers — so a row here decides them rather than restating them, and a field left out keeps the operator's own default. The two `runtimeInjects*` fields are the exception, deployment facts no Go code holds, and they answer different questions:    `runtimeInjectsDriver` marks a manufacturer whose user-space driver reaches a container   only through its container runtime, so that manufacturer's device-manager runs under the   RuntimeClass too. Every other vendor's device-manager reads its management library from a   hostPath mount the DaemonSet already makes.    `runtimeInjectsDevices` marks a manufacturer whose allocator contributes no device node of   its own, so its container runtime is the only thing that turns an allocation into `/dev`   entries inside the container. This is the WORKLOAD's need, not the device-manager's: such a   device-manager still reads its library from a hostPath and does not run under the class.   Ascend and Iluvatar are the cases in point: their allocators emit `ASCEND_VISIBLE_DEVICES` and   `IX_VISIBLE_DEVICES` and no device node, so without their runtime the container starts with the   variable set and no accelerator behind it — and no error anywhere. AMD used to be a third and   is not any more: its allocator injects `/dev/kfd` and the accelerator's DRM nodes itself.  Either of the two — never `runtimeName` — is what decides which RuntimeClasses this chart creates (`deviceManager.createRuntimeClasses`), because either one means the runtime's presence can be inferred: a vendor missing what it names cannot work at all unless its container toolkit registered the handler. `runtimeName` alone is only the class the operator will USE for a vendor. A vendor with neither field injects its own device nodes and needs no RuntimeClass, so the handler may well be absent while its accelerators work — and creating one there would break them: the operator attaches a RuntimeClass to a workload whenever one exists, so the kubelet would reject every Pod of that vendor for a runtime nothing configured. A class the vendor's own operator created is still used; this chart just never conjures one.  The keys are the manufacturer list: they become the worker's `--manufacturer` flag (which is where the `gpustack-cpu-info` NodeFeatureRule's vendor IDs come from, since the worker renders that rule itself), one device-manager DaemonSet each, and Kueue's credits mapping. Each DaemonSet only schedules on nodes NFD labelled with the matching PCI vendor, so adding a row is all it takes for a new vendor's devices to be labelled, detected and given a device-manager, and a row no node in the cluster carries simply runs nothing.  It lives under `global` because the vendored Kueue subchart reads it too, and `global` is the only channel Helm gives a subchart to this chart's values. The defaults are every manufacturer `pkg/nodefeature` knows, which a Go test asserts. Narrow the list by setting a row to `null` — an unwanted row is otherwise harmless (its DaemonSet schedules on no node), so this is about how much a release renders, not about what works. |
| nameOverride | string | `""` | Override the chart name used in resource names. |
| fullnameOverride | string | `""` | Override the fully qualified release name used as the base of resource names. |
| namespaceOverride | string | `""` | Namespace to deploy the resources into; defaults to the release namespace. |
| commonLabels | object | `{}` | Extra labels added to every resource. |
| commonAnnotations | object | `{}` | Extra annotations added to every resource. |
| image | object | `{"pullPolicy":"IfNotPresent","repository":"gpustack/gpustack-operator","tag":""}` | Default operator image (shared by the worker and the device-manager). Each component may override any of these keys via its own `image` block. |
| image.repository | string | `"gpustack/gpustack-operator"` | Operator image repository (shared by the worker and the device-manager). |
| image.tag | string | `""` | Operator image tag; defaults to "v<.Chart.AppVersion>" when empty. |
| image.pullPolicy | string | `"IfNotPresent"` | Operator image pull policy. |
| worker.enabled | bool | `true` | Deploy the worker (control plane). Disable to deploy only the device-managers. |
| worker.replicas | int | `1` | Number of operator (control plane) replicas. Leader election is always on, so extra replicas stand by; the reconcilers only ever run in one of them. |
| worker.strategyType | string | `"Recreate"` | Deployment strategy of the worker. The worker fronts the aggregated API and finishes its whole install (`Prepare`) before it serves, so a `RollingUpdate` keeps the OLD replica answering the old API until the new one turns Ready — which a failed install makes never. The chart's `Recreate` takes the old replica down first: the API pauses during an upgrade instead of serving a stale surface. `RollingUpdate` trades that pause for mixed-version serving — old and new replicas answer TOGETHER for the whole rollout, at any replica count — so set it only where every upgrade pair you roll through is known to be API-compatible in both directions. |
| worker.disableApplications | list | `["*"]` | Applications the worker must not install at runtime, or `*` for all of them. This chart deploys every one of them itself, so the default takes the worker out of that business entirely. Keep the wildcard: whenever this chart deploys the worker, anything left off the list makes the worker install a SECOND release of this same chart, whose render overlaps this one's. Helm refuses an object another release owns, so that install fails and the worker's startup with it. Handing a component back would mean disabling it here and in this chart's own switch for it, in step, through every upgrade — nothing checks that, which is why the supported split is all or nothing. The worker installs applications only where no chart deploys it, see [Installation Modes](https://github.com/gpustack/gpustack-operator/blob/main/docs/operate/installation-modes.md). The value is templated rather than appended through `extraArgs` because the flag accumulates across occurrences, so a second one could only ever disable more. Accepted names: `*`, `kueue`, `node-feature-discovery`, `csi-driver-nfs`, `csi-driver-s3`, `device-manager`, `model-manager`, `model-transfer`. |
| worker.instanceIsolationPodCIDRs | list | `[]` | The IPv4 pod CIDRs the Instance namespace-isolation NetworkPolicy carves out of its 0.0.0.0/0 external rule: Instance Pods stay reachable from their own namespace and from outside the cluster, and never from another namespace's Pods. The policy exists only while this list is non-empty — isolation is opt-in, and emptying the list collects the policy again. Reserved namespaces (kube-system and the operator's own) are never isolated. Needs a CNI that enforces NetworkPolicy (Calico is the documented one); find the values with `kubectl get ippools.crd.projectcalico.org` on a Calico-IPAM cluster, or `kubectl get nodes -o jsonpath='{.items[*].spec.podCIDRs}'` where the nodes carve the pod addresses. Rendered into the worker's GPUSTACK_INSTANCE_ISOLATION_POD_CIDRS environment variable; the Setting can also be edited at runtime through the Settings API without an upgrade. |
| worker.podDisruptionBudget.enabled | bool | `false` | Create a PodDisruptionBudget for the worker. Leave it off on a single-replica install, where it would only block node drains. |
| worker.podDisruptionBudget.minAvailable | int | `1` | Minimum number of worker pods that must stay available, as a count or a percentage. Keep it below `replicas`, or no node can ever be drained. |
| worker.securePort | int | `31443` | Secure serving port of the worker container. |
| worker.image | object | `{}` | Per-worker image overrides (`repository`/`tag`/`pullPolicy`); unset keys fall back to the chart-level `image`. |
| worker.dataDir | string | `"/var/lib/gpustack"` | Host path mounted at /var/lib/gpustack for persistent operator data. |
| worker.resources | object | `{"limits":{"cpu":"4","memory":"8Gi"},"requests":{"cpu":"100m","memory":"128Mi"}}` | Resource requests and limits for the worker container. |
| worker.nodeSelector | object | `{}` | Node selector for the worker; falls back to `global.nodeSelector` when empty. |
| worker.tolerations | list | `[{"effect":"NoSchedule","key":"node-role.kubernetes.io/master","operator":"Exists"},{"effect":"NoSchedule","key":"node-role.kubernetes.io/controlplane","operator":"Exists"},{"effect":"NoSchedule","key":"node-role.kubernetes.io/control-plane","operator":"Exists"},{"effect":"NoSchedule","key":"CriticalAddonsOnly","operator":"Exists"}]` | Tolerations for the worker. Defaults let the control plane run on control-plane/master nodes. |
| worker.topologySpreadConstraints | list | `[]` | Topology spread constraints for the worker. This is where node spread belongs: the default anti-affinity is only `preferred`, on purpose, so three replicas still schedule on a two-node cluster. An entry that omits `labelSelector` gets the worker's own. |
| worker.affinity | object | `{}` | Affinity for the worker, replacing the default `preferred` pod anti-affinity that keeps replicas off one node without ever making one unschedulable. |
| worker.extraArgs | list | `[]` | Extra command-line arguments appended to the worker container args. |
| worker.env | object | `{}` | Extra environment variables for the worker, as a name/value map. |
| deviceManager.enabled | bool | `true` | Deploy the per-manufacturer device-manager DaemonSets. |
| deviceManager.securePort | int | `32443` | Secure serving port of the device-manager container. |
| deviceManager.containerdConfigDir | string | `"/etc/containerd"` | Directory holding the container engine's `config.toml`, mounted read-only into every device manager at that same path and named to them as `GPUSTACK_CONTAINERD_CONFIG_DIR`.  A distribution that keeps it elsewhere is served by naming that directory here: k3s uses `/var/lib/rancher/k3s/agent/etc/containerd` and RKE2 `/var/lib/rancher/rke2/agent/etc/containerd`. Set it to the directory itself, never the tree above it — on those two distributions that tree also holds the cluster's tokens and keys. An empty value mounts nothing and passes nothing.  It is read for one purpose: a device-injection strategy of `auto` needs to know whether the container engine resolves CDI requests, and which runtime handler a Pod naming no `runtimeClassName` runs under. With the configuration unreadable, `auto` keeps the environment-variable channel. Nothing else depends on it. |
| deviceManager.image | object | `{}` | Per-device-manager image overrides (`repository`/`tag`/`pullPolicy`); unset keys fall back to the chart-level `image`. |
| deviceManager.networkPolicy | object | `{"enabled":false,"extraIngress":[],"scrapers":[]}` | Restrict who may reach the device-manager's secure port.  That port serves `/metrics`, which lists every Instance running on the node — names, namespaces, declared sizes, live usage and accelerator IDs — to anything that can reach it, and it is unauthenticated. Enabling this is recommended on a multi-tenant cluster. |
| deviceManager.networkPolicy.enabled | bool | `false` | Deploy the NetworkPolicy.  It only takes effect on a CNI that enforces NetworkPolicy; on one that does not, the object is inert rather than an error. On a CNI that enforces policy but does not exempt node-local traffic it also cuts the kubelet's probes, which would take every device-manager NotReady — see `extraIngress`. |
| deviceManager.networkPolicy.scrapers | list | `[]` | Peers admitted to the secure port besides the worker, as NetworkPolicy `from` entries (`podSelector`, `namespaceSelector`, `ipBlock`). This is where a Prometheus living outside the operator's namespace goes, e.g. `[{namespaceSelector: {matchLabels: {kubernetes.io/metadata.name: monitoring}}}]`. |
| deviceManager.networkPolicy.extraIngress | list | `[]` | Whole ingress rules appended verbatim, for what `scrapers` cannot express.  NetworkPolicy has no peer meaning "the node this pod runs on", and the kubelet's probes come from the node's host network namespace. Mainstream CNIs exempt that traffic, but upstream leaves it implementation-defined — so on a CNI that does not, admit the node's address range here, e.g. `[{from: [{ipBlock: {cidr: 10.0.0.0/8}}]}]`. |
| deviceManager.createRuntimeClasses | bool | `true` | Create a RuntimeClass for every manufacturer whose `global.manufacturers` row sets `runtimeInjectsDriver` or `runtimeInjectsDevices`, where the cluster does not already have one. That is the set whose container runtime is certain to be installed, since without it those accelerators cannot work at all — see the note on `global.manufacturers`. Disable when something else provides them (e.g. a vendor GPU operator). |
| deviceManager.resources | object | `{"limits":{"cpu":"4","memory":"8Gi"},"requests":{"cpu":"100m","memory":"128Mi"}}` | Resource requests and limits for each device-manager container. |
| deviceManager.tolerations | list | `[{"operator":"Exists"}]` | Tolerations for the device-manager DaemonSets. Defaults tolerate every taint so a manager schedules on any node carrying the matching accelerator. |
| deviceManager.extraArgs | list | `[]` | Extra command-line arguments appended to each device-manager container args. |
| deviceManager.env | object | `{}` | Extra environment variables for the device-manager, as a name/value map. |
| modelManager.enabled | bool | `true` | Deploy the model-manager: the CSI node plugin that delivers a Hugging Face ModelArtifact's weights from each node's cache, and its CSIDriver `model.csi.gpustack.ai`.  When enabled, the chart declares `GPUSTACK_MODEL_ARTIFACT_DELIVERY_MODE=Node`, so the chart owns `model-artifact-delivery-mode`. The worker reasserts `Node` on every start and reverts a runtime edit to the Setting. `modelManager.enabled` is the only signal that reaches this value; the worker flag `--model-manager-service-account` defaults to a non-empty name and cannot indicate whether the plugin is deployed. With the plugin enabled, upgrading from a version without the Setting rolls every ModelDeployment on a Hugging Face artifact once, to node delivery. |
| modelManager.rootPath | string | `"/var/lib/gpustack/models"` | The node's model cache directory, a hostPath. Mount a dedicated filesystem here: on one shared with kubelet the plugin caps its high watermark below kubelet's eviction and image collection thresholds. Changing it points the plugin at an empty cache; nothing is migrated or removed from the old path. |
| modelManager.kubeletDir | string | `"/var/lib/kubelet"` | kubelet's root directory, the convention the bundled CSI drivers follow. The plugin mounts its pods directory with Bidirectional propagation so its bind mounts reach the Pods. |
| modelManager.securePort | int | `32444` | Secure serving port of the model-manager container: metrics, readiness and liveness. |
| modelManager.port | int | `32445` | TCP port the node's published trees are served to the other nodes' plugins on, for node-to-node sync, enabled by default; `0` is off. Plugins authenticate each other with a projected ServiceAccount token (audience `gpustack-model-peer`), and the networkPolicy below keeps tenant Pods off the port. |
| modelManager.peerSync.maxServingStreams | int | `8` | How many peer file answers a node serves at once. |
| modelManager.peerSync.streamsPerSource | int | `4` | How many requests a node opens to one peer at once. |
| modelManager.networkPolicy.enabled | bool | `true` | Deploy the NetworkPolicy that keeps tenant Pods off the peer port (and the secure port, except from the worker). It only takes effect on a CNI that enforces NetworkPolicy. |
| modelManager.networkPolicy.scrapers | list | `[]` | Whoever scrapes /metrics. |
| modelManager.networkPolicy.extraIngress | list | `[]` | Additional ingress rules, verbatim. |
| modelManager.image | object | `{}` | Per-model-manager image overrides (`repository`/`tag`/`pullPolicy`); unset keys fall back to the chart-level `image`. |
| modelManager.registrar.image | object | `{"repository":"docker.io/gpustack/mirrored-csi-node-driver-registrar","tag":"v2.17.0"}` | The node-driver-registrar sidecar's image: the mirror the bundled NFS and S3 CSI drivers pin, rewritten by the `global` image settings like every other image. |
| modelManager.resources | object | `{"limits":{"cpu":"4","memory":"2Gi"},"requests":{"cpu":"100m","memory":"128Mi"}}` | Resource requests and limits for each model-manager container. |
| modelManager.nodeSelector | object | `{}` | Node selector for the model-manager DaemonSet, merged over `global.nodeSelector`. |
| modelManager.tolerations | list | `[{"operator":"Exists"}]` | Tolerations for the model-manager DaemonSet. Defaults tolerate every taint, so every node a workload may land on can mount its weights. |
| modelManager.extraArgs | list | `[]` | Extra command-line arguments appended to the model-manager container args. |
| modelTransfer | object | `{"brokerResources":{"limits":{"memory":"512Mi"},"requests":{"cpu":"100m","memory":"128Mi"}},"enabled":true,"env":{},"extraArgs":[],"images":{"amd":"gpustack/model-transfer:v0.1.0-rocm7.2","ascend":"gpustack/model-transfer:v0.1.0-cann9.2-a5","nvidia":"gpustack/model-transfer:v0.1.0-cuda12.9"},"nodeSelector":{},"serviceAccount":{"name":""},"source":{"maxMemoryBytes":0,"maxSessions":64,"minMemoryBytes":1073741824},"tolerations":[{"operator":"Exists"}],"workerResources":{}}` | Remote weight delivery (model-transfer): the source runtime's identity, the per-manufacturer broker+worker DaemonSets, their serving certificates and headless Services. Remote delivery policy defaults to `Prefer` via the worker's built-in `model-artifact-remote-delivery-policy` Setting — a cluster without a prepared `ModelPrefetch` source keeps every Pod, condition and status field unchanged, and preparing a source enables remote delivery with local fallback. |
| modelTransfer.enabled | bool | `true` | Deploy the remote delivery source runtime: a ServiceAccount and the minimal RBAC a source broker runs under, one broker+worker DaemonSet per manufacturer named in `images`, the session serving certificate each broker's TLS-only listener serves under, and a headless Service per manufacturer an engine resolves exact source endpoints through. Nothing here grants a device, a cache path, or a tenant secret, and a disk-only warm-up Pod never uses this identity. With `images` empty the identity ships and no source runtime does; with `enabled=false` none of it renders and the chart declares `GPUSTACK_MODEL_ARTIFACT_REMOTE_DELIVERY_POLICY=Disabled` on the worker. |
| modelTransfer.serviceAccount | object | `{"name":""}` | The source workers' ServiceAccount name; an empty name derives `<fullname>-model-transfer`. |
| modelTransfer.images | object | `{"amd":"gpustack/model-transfer:v0.1.0-rocm7.2","ascend":"gpustack/model-transfer:v0.1.0-cann9.2-a5","nvidia":"gpustack/model-transfer:v0.1.0-cuda12.9"}` | Manufacturer-to-image map for the remote delivery source DaemonSets (`amd`, `ascend`, `nvidia`). Values are full image references, for example {nvidia: "gpustack/model-transfer:v0.1.0-cuda12.9", amd: "gpustack/model-transfer:v0.1.0-rocm7.2", ascend: "gpustack/model-transfer:v0.1.0-cann9.2-a5"}; `global.imageRegistry` (or `global.hub`) and `global.imageNamespace` rewrite the registry and namespace segments when set while preserving the image's own tag, and a missing manufacturer ships no source runtime for itself. Each supported key maps to its `global.manufacturers` row: the row's PCI vendor is the DaemonSet's placement requirement (`nodeSelector`) and its runtime fields decide driver injection. Defaults cover NVIDIA, AMD and Ascend A5. Disk warm-up retains its separate lightweight Python Alpine image. @schema type: object additionalProperties:   type: string   minLength: 1 @schema |
| modelTransfer.source | object | `{"maxMemoryBytes":0,"maxSessions":64,"minMemoryBytes":1073741824}` | The source broker's node memory window and session policy. `maxMemoryBytes` is the transfer buffer ceiling: `0` derives one sixteenth of the node's total RAM at node start, floored at `minMemoryBytes`, and a positive value below `minMemoryBytes` silently resolves up to it. `minMemoryBytes` defaults to 1 GiB (1073741824); a lower value resolves up to 1 GiB. The worker checks available RAM before initial allocation when it can read the figure. `maxSessions` caps concurrent source sessions; zero resolves to 64. Negative values are rejected by chart validation. @schema type: object properties:   maxMemoryBytes:     type: integer   minMemoryBytes:     type: integer   maxSessions:     type: integer @schema |
| modelTransfer.source.maxMemoryBytes | int | `0` | The node's transfer buffer ceiling in bytes; `0` follows the node's RAM. |
| modelTransfer.source.minMemoryBytes | int | `1073741824` | The smallest source buffer the node still serves, in bytes. |
| modelTransfer.source.maxSessions | int | `64` | The node's concurrent source-session cap. |
| modelTransfer.nodeSelector | object | `{}` | Node selector for the per-vendor source DaemonSets, merged under each manufacturer's mandatory PCI label; it narrows which selected nodes run a vendor's source Pod. |
| modelTransfer.tolerations | list | `[{"operator":"Exists"}]` | Tolerations for the per-vendor source DaemonSets. Defaults tolerate every taint, so every node carrying the matching accelerator can serve its weights remotely. |
| modelTransfer.env | object | `{}` | Environment entries on the source broker and worker, layered after image defaults and before managed identity. `GPUSTACK_MODEL_TRANSFER_HIXL_RESIDENT_BUDGET_BYTES` sets the HIXL registration paging threshold and budget (default 16 GiB; nonzero values below 1 GiB resolve up to 1 GiB, while zero uses the default). `GPUSTACK_MODEL_TRANSFER_SOURCE_MAX_MEMORY_BYTES` and `GPUSTACK_MODEL_TRANSFER_SOURCE_MIN_MEMORY_BYTES` are managed by the chart from `source.maxMemoryBytes` and `source.minMemoryBytes`. The engine reader reads `GPUSTACK_MODEL_TRANSFER_MAX_WINDOW_BYTES` from its own environment (default 8 GiB; the legal range is 1 GiB through 1 TiB); this map does not configure serving engines. These windows do not replace the Binding grant or the node ceiling. @schema type: object additionalProperties:   type: string @schema |
| modelTransfer.extraArgs | list | `[]` | Extra argument lines appended verbatim to the source broker's command, after the chart's own arguments. Each entry is one argument word. @schema type: array items:   type: string @schema |
| modelTransfer.brokerResources | object | `{"limits":{"memory":"512Mi"},"requests":{"cpu":"100m","memory":"128Mi"}}` | The broker container's resources. |
| modelTransfer.workerResources | object | `{}` | The source worker container's resources. Empty by default, which renders no resources block so the worker sizes its transfer buffer from the node's RAM via `/proc/meminfo` without a container cgroup memory cap. Set explicit requests and limits here when you want Kubernetes resource bounds on the worker container. @schema type: object @schema |
| migrate | object | `{"image":{}}` | Migration hook Jobs. A pre-install/pre-upgrade Job reaps a Kueue left stranded by an interrupted teardown, and on an upgrade applies the vendored subcharts' CRDs, which Helm itself applies on install only. A post-upgrade Job retires the release records of the per-application releases these subcharts replaced and prunes what they left behind. Both run the operator image, which bundles kubectl, helm and this chart; `helm upgrade --no-hooks` skips them. |
| migrate.image | object | `{}` | Per-hook image overrides (`repository`/`tag`/`pullPolicy`); unset keys fall back to the chart-level `image`. Overridable so an upgrade is never blocked by an operator tag that is not mirrored yet — at the cost that the CRDs the hook applies are then the ones vendored by the image it does run. |
| kueue | object | see the `kueue.*` keys below | [Kueue](https://kueue.sigs.k8s.io) subchart (chart 0.18.11). |
| kueue.enabled | bool | `true` | Deploy the bundled Kueue. |
| kueue.fullnameOverride | string | `"kueue"` | Name the Kueue resources after a fixed "kueue" prefix instead of the release, so that this subchart and the runtime install render identical resource names. |
| kueue.controllerManager.replicas | int | `1` | Number of Kueue controller manager replicas. `managerConfig` below elects a leader, so extra replicas stand by — but every one of them serves the admission webhook, and that is what a highly available install buys: with a single replica, losing its node blocks Pod creation in every namespace Kueue manages until it is rescheduled. |
| kueue.controllerManager.podDisruptionBudget.enabled | bool | `false` | Create a PodDisruptionBudget for the Kueue controller manager. Enable it together with `replicas` above; on a single replica it would only block node drains. |
| kueue.controllerManager.podDisruptionBudget.minAvailable | int | `1` | Minimum number of Kueue controller manager pods that must stay available, as a count or a percentage. Keep it below `replicas`, or no node can ever be drained. |
| kueue.controllerManager.topologySpreadConstraints | list | `[]` | Topology spread constraints for the Kueue controller manager, rendered as given. Unlike the worker's, these carry no selector of their own, so a `DoNotSchedule` spread across nodes needs `labelSelector: {matchLabels: {app.kubernetes.io/name: kueue, control-plane: controller-manager}}` spelled out. |
| kueue.controllerManager.tolerations | list | `[{"effect":"NoSchedule","key":"node-role.kubernetes.io/master","operator":"Exists"},{"effect":"NoSchedule","key":"node-role.kubernetes.io/controlplane","operator":"Exists"},{"effect":"NoSchedule","key":"node-role.kubernetes.io/control-plane","operator":"Exists"},{"effect":"NoSchedule","key":"CriticalAddonsOnly","operator":"Exists"}]` | Tolerations for the Kueue controller manager. Defaults tolerate only the control-plane taints, as the worker's do. A blanket `operator: "Exists"` would also tolerate `node.kubernetes.io/unschedulable`, sending an evicted pod straight back to the node being drained, and would opt out of the default five-minute eviction from an unreachable node. Where the only nodes left for it carry a taint of your own, add that taint here. |
| kueue.controllerManager.manager.image.repository | string | `"docker.io/gpustack/mirrored-kueue"` | Kueue controller manager image repository. |
| kueue.controllerManager.manager.image.tag | string | `"v0.18.11"` | Kueue controller manager image tag, stated rather than inherited so a subchart bump cannot move the image without the diff showing it. |
| kueue.controllerManager.manager.image.pullPolicy | string | `"IfNotPresent"` | Kueue controller manager image pull policy. |
| kueue.controllerManager.manager.podAnnotations | object | `{"gpustack.ai/managed":"true"}` | Annotations of the Kueue controller manager pods, marking them as managed by the operator. |
| kueue.controllerManager.manager.resources | object | `{"limits":{"cpu":"2","memory":"4Gi"},"requests":{"cpu":"100m","memory":"128Mi"}}` | Resource requests and limits for the Kueue controller manager container. |
| kueue.managerConfig.controllerManagerConfigYaml | string | controllerManagerConfigYaml | Kueue's controller_manager_config.yaml, delivered through the manager-config ConfigMap. Two keys are absent on purpose and rendered by this chart instead, because Helm merges a subchart's values rather than templating them: `resources.transformations`, the credits mapping derived from `global.manufacturers`, which a user copying this string must not be able to drop silently; and `managedJobsNamespaceSelector`, whose default follows the release namespace. Everything else is maintained here, and a selector stated here still wins. |
| node-feature-discovery | object | see the `node-feature-discovery.*` keys below | [Node Feature Discovery](https://kubernetes-sigs.github.io/node-feature-discovery) subchart (chart 0.19.0). |
| node-feature-discovery.enabled | bool | `true` | Deploy the bundled Node Feature Discovery. |
| node-feature-discovery.fullnameOverride | string | `"node-feature-discovery"` | Name the NFD resources after a fixed "node-feature-discovery" prefix instead of the release, so that this subchart and an NFD installed by anything else render identical resource names. Without it the two run side by side, each labelling the same nodes. |
| node-feature-discovery.image.repository | string | `"docker.io/gpustack/mirrored-node-feature-discovery"` | NFD image repository; the master, the worker and the gc all run it. |
| node-feature-discovery.image.tag | string | `"v0.19.0-gpustack1"` | NFD image tag, stated rather than inherited so a subchart bump cannot move the image without the diff showing it. |
| node-feature-discovery.master.replicaCount | int | `1` | Number of NFD master replicas. The master is what turns a device-manager's detections into node labels, so while it is down no node is ever (re)classified and the scheduling chain stalls for new or changed nodes. Above one, NFD's own chart adds `-enable-leader-election` for you; the standbys watch without writing. NFD's templates render no topology spread constraints, so spreading these replicas across nodes means setting `master.affinity` below — which replaces NFD's own preference for control-plane nodes rather than adding to it. |
| node-feature-discovery.master.affinity | object | `{"nodeAffinity":{"preferredDuringSchedulingIgnoredDuringExecution":[{"preference":{"matchExpressions":[{"key":"node-role.kubernetes.io/control-plane","operator":"Exists"}]},"weight":1}]}}` | Affinity for the NFD master, and the only way to spread its replicas across nodes: NFD renders no topology spread constraints. Stated here because a spread knob a user cannot find in this file is a knob that does not exist, and because replacing it wholesale is what setting it does.  It is NFD's own default — a preference for control-plane nodes — with one deliberate change: the role label is matched with `Exists` rather than `In [""]`. That label's value is a convention, not an API: kubeadm and kind set it empty, k3s and RKE2 set it to "true", so a value test silently matches nothing on those and the preference quietly stops existing. `Exists` is also what every other control-plane matcher in this file uses, tolerations and both CSI drivers included. Being stated pins the rest of the block: re-read NFD's default when bumping the subchart, as with every image tag here. |
| node-feature-discovery.master.podDisruptionBudget.enable | bool | `false` | Create a PodDisruptionBudget for the NFD master. Enable it together with `replicaCount` above; on a single replica it would only block node drains. NFD spells this key `enable`, not `enabled`. |
| node-feature-discovery.master.podDisruptionBudget.minAvailable | int | `1` | Minimum number of NFD master pods that must stay available, as a count or a percentage. Keep it below `replicaCount`, or no node can ever be drained. |
| node-feature-discovery.master.annotations | object | `{"gpustack.ai/managed":"true"}` | Annotations added to the NFD master pods. |
| node-feature-discovery.master.deploymentAnnotations | object | `{"gpustack.ai/managed":"true"}` | Annotations added to the NFD master Deployment. |
| node-feature-discovery.master.serviceAccount.annotations | object | `{"gpustack.ai/managed":"true"}` | Annotations added to the NFD master ServiceAccount. |
| node-feature-discovery.master.tolerations | list | `[{"effect":"NoSchedule","key":"node-role.kubernetes.io/master","operator":"Exists"},{"effect":"NoSchedule","key":"node-role.kubernetes.io/controlplane","operator":"Exists"},{"effect":"NoSchedule","key":"node-role.kubernetes.io/control-plane","operator":"Exists"},{"effect":"NoSchedule","key":"CriticalAddonsOnly","operator":"Exists"}]` | Tolerations for the NFD master. Defaults tolerate only the control-plane taints, as the worker's do. A blanket `operator: "Exists"` would also tolerate `node.kubernetes.io/unschedulable`, sending an evicted pod straight back to the node being drained, and would opt out of the default five-minute eviction from an unreachable node. Where the only nodes left for it carry a taint of your own, add that taint here. |
| node-feature-discovery.master.config.restrictions | object | `{"allowOverwrite":true,"denyNodeFeatureLabels":false,"disableAnnotations":false,"disableExtendedResources":false,"disableLabels":false,"disableTaints":false}` | What the NFD master is allowed to write. Every value here restates an NFD default, stated because the whole chain depends on it: labels, taints, annotations and extended resources all stay enabled, an existing label may be overwritten, and the labels a NodeFeature asks for are honoured — that last one is how a device-manager's detections reach its node.  `nodeFeatureNamespaceSelector` is deliberately absent. Pinned to one namespace it makes the master ignore every NodeFeature created anywhere else, which is exactly what taking over a cluster's existing NFD must not do: a vendor GPU operator keeps its NodeFeatures in its own namespace, and they are the features being adopted. Unset means every namespace, so — together with the two permissive keys above — a NodeFeature anywhere can influence node labels; `denyNodeFeatureLabels` is the lever that tightens it. |
| node-feature-discovery.worker.annotations | object | `{"gpustack.ai/managed":"true"}` | Annotations added to the NFD worker pods. |
| node-feature-discovery.worker.daemonsetAnnotations | object | `{"gpustack.ai/managed":"true"}` | Annotations added to the NFD worker DaemonSet. |
| node-feature-discovery.worker.serviceAccount.annotations | object | `{"gpustack.ai/managed":"true"}` | Annotations added to the NFD worker ServiceAccount. |
| node-feature-discovery.worker.tolerations | list | `[{"operator":"Exists"}]` | Tolerations for the NFD worker. Defaults tolerate every taint, so a node is discovered whatever it is tainted for. |
| node-feature-discovery.worker.config.core.labelSources | list | `["cpu","pci","custom","system"]` | Feature sources the worker collects. `custom` is what makes the `gpustack-cpu-info` NodeFeatureRule the operator applies evaluate. |
| node-feature-discovery.worker.config.core.labelWhiteList | string | `"^(pci-|cpu-model\\.|system-os_release\\.|acceleratable)"` | Only the labels this chart consumes are published, so NFD does not cover the nodes in features nothing reads — `system-os_release.` excepted, which a vendor GPU operator reads. |
| node-feature-discovery.worker.config.sources.pci.deviceClassWhitelist | list | `["02","03","0b","12"]` | PCI device classes to label, as class-code prefixes: display controllers, processing accelerators and the co-processors accelerators present as (see https://admin.pci-ids.ucw.cz/read/PD). The `gpustack-cpu-info` NodeFeatureRule matches the same classes, so it sees exactly the devices NFD was told to label; the operator renders that rule from `pkg/nodefeature`, and a Go test holds the two lists equal. Narrowing this list without narrowing that one labels fewer devices than the rule expects. |
| node-feature-discovery.worker.config.sources.pci.deviceLabelFields | list | `["vendor"]` | Device fields to label. `vendor` is what the NodeFeatureRule matches the managed `global.manufacturers`' PCI vendor IDs against. |
| node-feature-discovery.gc.annotations | object | `{"gpustack.ai/managed":"true"}` | Annotations added to the NFD gc pods. |
| node-feature-discovery.gc.deploymentAnnotations | object | `{"gpustack.ai/managed":"true"}` | Annotations added to the NFD gc Deployment. |
| node-feature-discovery.gc.serviceAccount.annotations | object | `{"gpustack.ai/managed":"true"}` | Annotations added to the NFD gc ServiceAccount. |
| node-feature-discovery.gc.tolerations | list | `[{"effect":"NoSchedule","key":"node-role.kubernetes.io/master","operator":"Exists"},{"effect":"NoSchedule","key":"node-role.kubernetes.io/controlplane","operator":"Exists"},{"effect":"NoSchedule","key":"node-role.kubernetes.io/control-plane","operator":"Exists"},{"effect":"NoSchedule","key":"CriticalAddonsOnly","operator":"Exists"}]` | Tolerations for the NFD gc. Defaults tolerate only the control-plane taints, as the worker's do. A blanket `operator: "Exists"` would also tolerate `node.kubernetes.io/unschedulable`, sending an evicted pod straight back to the node being drained, and would opt out of the default five-minute eviction from an unreachable node. Where the only nodes left for it carry a taint of your own, add that taint here. |
| csi-driver-nfs | object | see the `csi-driver-nfs.*` keys below | [csi-driver-nfs](https://github.com/kubernetes-csi/csi-driver-nfs) subchart (chart 4.13.4). |
| csi-driver-nfs.enabled | bool | `true` | Deploy the bundled NFS CSI driver. |
| csi-driver-nfs.driver.name | string | `"nfs.csi.gpustack.ai"` | CSI driver name. Namespaced to gpustack so this driver coexists with a cluster's own csi-driver-nfs, and matched by `kuberess.CSIProvisionerNFS`, which the worker writes into the StorageClasses it provisions. |
| csi-driver-nfs.image | object | `{"baseRepo":"docker.io","csiProvisioner":{"repository":"/gpustack/mirrored-csi-provisioner","tag":"v6.3.0"},"csiResizer":{"repository":"/gpustack/mirrored-csi-resizer","tag":"v2.2.0"},"csiSnapshotter":{"repository":"/gpustack/mirrored-csi-snapshotter","tag":"v8.6.0"},"livenessProbe":{"repository":"/gpustack/mirrored-csi-livenessprobe","tag":"v2.19.0"},"nfs":{"repository":"/gpustack/mirrored-csi-nfs-driver","tag":"v4.13.4"},"nodeDriverRegistrar":{"repository":"/gpustack/mirrored-csi-node-driver-registrar","tag":"v2.17.0"}}` | Mirrored images. `baseRepo` is joined with each leading-slash `repository`. Every tag is stated rather than inherited from the chart, so what this release pulls is readable here and a subchart bump cannot move an image without the diff showing it. These are the tags chart 4.13.4 ships, the driver's included, and each one is mirrored — an unmirrored tag would put every install in ImagePullBackOff. The three sidecars this driver shares with `csi-driver-s3` (`csiProvisioner`, `livenessProbe`, `nodeDriverRegistrar`) carry the same tag on both, so a release ships one image per component rather than two versions of each. The `externalSnapshotter` image is absent because that component is off, and turning it on would need a mirror first. |
| csi-driver-nfs.controller.replicas | int | `1` | Number of NFS controller (provisioner) replicas. Every sidecar runs with `--leader-election`, so extra replicas stand by. Losing the controller delays volume provisioning, resizing and snapshotting; volumes already mounted keep working, because the mounting side is the node DaemonSet. This chart renders no PodDisruptionBudget for the controller, and it honours `controller.affinity` only when that affinity carries `nodeSelectorTerms` — a pod anti-affinity is silently dropped — so without the spread below, replicas may share a node. Sharing one is not just weaker redundancy here: the pods run on the host network and bind the liveness health port on it, so the second pod on a node crash-loops on the bind and the Deployment never reaches full readiness. |
| csi-driver-nfs.controller.strategyType | string | `"Recreate"` | Deployment strategy of the NFS controller. The chart's `Recreate` takes every replica down before starting the new one, which gives up the failover `replicas` above just bought; set `RollingUpdate` alongside it. |
| csi-driver-nfs.controller.name | string | `"csi-nfs-controller"` | Name of the NFS controller Deployment and of the pods it owns. |
| csi-driver-nfs.controller.dnsPolicy | string | `"ClusterFirstWithHostNet"` | DNS policy of the NFS controller pods. |
| csi-driver-nfs.controller.affinity | object | `{}` | Affinity of the NFS controller pods. Honoured only when it carries `nodeSelectorTerms` (see `replicas` above), which makes it a node-placement knob and nothing else. |
| csi-driver-nfs.controller.nodeSelector | object | `{}` | Node selector of the NFS controller pods. |
| csi-driver-nfs.controller.topologySpreadConstraints | list | `[]` | Topology spread constraints of the NFS controller pods, rendered by a vendored patch the upstream chart does not carry. Above one replica a `DoNotSchedule` spread over `kubernetes.io/hostname` is required, not just prudent — see `replicas` above. The constraint needs its `labelSelector` spelled out: `{matchLabels: {app: csi-nfs-controller}}`. |
| csi-driver-nfs.controller.priorityClassName | string | `"system-cluster-critical"` | Priority class of the NFS controller pods. `system-cluster-critical` keeps provisioning working while a node is under pressure. |
| csi-driver-nfs.controller.tolerations | list | `[{"effect":"NoSchedule","key":"node-role.kubernetes.io/master","operator":"Exists"},{"effect":"NoSchedule","key":"node-role.kubernetes.io/controlplane","operator":"Exists"},{"effect":"NoSchedule","key":"node-role.kubernetes.io/control-plane","operator":"Exists"},{"effect":"NoSchedule","key":"CriticalAddonsOnly","operator":"Exists"}]` | Tolerations of the NFS controller pods. The defaults let the provisioner run on control-plane nodes. |
| csi-driver-nfs.node.name | string | `"csi-nfs-node"` | Name of the NFS node DaemonSet and of the pods it owns. This is the mounting side: one pod per node, so it has no replica count or disruption budget to configure. |
| csi-driver-nfs.node.dnsPolicy | string | `"ClusterFirstWithHostNet"` | DNS policy of the NFS node pods. `ClusterFirstWithHostNet` is what lets an NFS server named in the cluster's DNS resolve from a host-networked mount. |
| csi-driver-nfs.node.affinity | object | `{}` | Affinity of the NFS node pods. Rendered as given, unlike the controller's. |
| csi-driver-nfs.node.nodeSelector | object | `{}` | Node selector of the NFS node pods, narrowing which nodes can mount NFS volumes. The chart adds `kubernetes.io/os: linux` on top of whatever is set here. |
| csi-driver-nfs.node.priorityClassName | string | `"system-cluster-critical"` | Priority class of the NFS node pods. |
| csi-driver-nfs.node.tolerations | list | `[{"operator":"Exists"}]` | Tolerations of the NFS node pods. The defaults tolerate every taint, so a volume can be mounted on any node the scheduler picks. |
| csi-driver-nfs.nodeDriverRegistrar.livenessProbe.enabled | bool | `false` | Leave the node-driver-registrar's own liveness probe off; the node plugin already runs one on its health port. |
| csi-driver-nfs.rbac.name | string | `"csi-nfs"` | Prefix of the driver's ClusterRole and ClusterRoleBinding names. |
| csi-driver-s3 | object | see the `csi-driver-s3.*` keys below | [csi-driver-s3](https://github.com/thxcode/k8s-csi-s3) subchart (chart 0.43.7). |
| csi-driver-s3.enabled | bool | `true` | Deploy the bundled S3 CSI driver. |
| csi-driver-s3.driver.name | string | `"s3.csi.gpustack.ai"` | CSI driver name. Namespaced to gpustack so this driver coexists with a cluster's own S3 CSI driver, and matched by `kuberess.CSIProvisionerS3`, which the worker writes into the StorageClasses it provisions. |
| csi-driver-s3.images | object | `{"csiProvisioner":"docker.io/gpustack/mirrored-csi-provisioner:v6.3.0","livenessProbe":"docker.io/gpustack/mirrored-csi-livenessprobe:v2.19.0","nodeDriverRegistrar":"docker.io/gpustack/mirrored-csi-node-driver-registrar:v2.17.0","s3":"docker.io/gpustack/mirrored-csi-s3-driver:v0.43.7"}` | Mirrored images. This chart stores whole `registry/namespace/name:tag` references with no separate tag key. The three sidecars are the same images, at the same tags, that `csi-driver-nfs` pulls: they are shared components, and shipping one tag per component keeps a release from carrying two versions of each. Upstream pins all three lower than the NFS chart does, so they follow the NFS chart rather than this one — which is what the `feature-gates.patch` is for: provisioner v6.3.0 has no `HonorPVReclaimPolicy` gate left to set, and this chart's controller still passed it. |
| csi-driver-s3.controller.replicas | int | `1` | Number of S3 controller (provisioner) replicas. The provisioner sidecar runs with `--leader-election`, so extra replicas stand by. Losing the controller delays volume provisioning; volumes already mounted keep working, because the mounting side is the node DaemonSet. This chart renders neither a PodDisruptionBudget nor topology spread constraints for the controller, and it honours `controller.affinity` only when that affinity carries `nodeSelectorTerms` — a pod anti-affinity is silently dropped — so replicas may share a node. Sharing one costs node-level redundancy but not readiness: unlike the NFS controller, these pods run on the pod network, so no host port collides. |
| csi-driver-s3.controller.strategyType | string | `"Recreate"` | Deployment strategy of the S3 controller. The chart's `Recreate` takes every replica down before starting the new one, which gives up the failover `replicas` above just bought; set `RollingUpdate` alongside it. |
| csi-driver-s3.controller.name | string | `"csi-s3-controller"` | Name of the S3 controller Deployment and of the pods it owns. |
| csi-driver-s3.controller.affinity | object | `{}` | Affinity of the S3 controller pods. Honoured only when it carries `nodeSelectorTerms` (see `replicas` above), which makes it a node-placement knob and nothing else. This chart renders no `dnsPolicy` for the controller, so there is no key for it. |
| csi-driver-s3.controller.nodeSelector | object | `{}` | Node selector of the S3 controller pods. |
| csi-driver-s3.controller.priorityClassName | string | `"system-cluster-critical"` | Priority class of the S3 controller pods. `system-cluster-critical` keeps provisioning working while a node is under pressure. |
| csi-driver-s3.controller.tolerations | list | `[{"effect":"NoSchedule","key":"node-role.kubernetes.io/master","operator":"Exists"},{"effect":"NoSchedule","key":"node-role.kubernetes.io/controlplane","operator":"Exists"},{"effect":"NoSchedule","key":"node-role.kubernetes.io/control-plane","operator":"Exists"},{"effect":"NoSchedule","key":"CriticalAddonsOnly","operator":"Exists"}]` | Tolerations of the S3 controller pods. The defaults let the provisioner run on control-plane nodes. |
| csi-driver-s3.node.name | string | `"csi-s3-node"` | Name of the S3 node DaemonSet and of the pods it owns. This is the mounting side: one pod per node, so it has no replica count or disruption budget to configure. |
| csi-driver-s3.node.dnsPolicy | string | `"ClusterFirstWithHostNet"` | DNS policy of the S3 node pods. It governs the node pod's own containers only: the default mounter (geesefs) runs as a systemd unit on the host and resolves the volume's endpoint with the host resolver, so an in-cluster object store endpoint must be written as a ClusterIP (or a name the host resolves) unless the mount runs in-container with `--no-systemd`. |
| csi-driver-s3.node.affinity | object | `{}` | Affinity of the S3 node pods. Rendered as given, unlike the controller's. |
| csi-driver-s3.node.nodeSelector | object | `{}` | Node selector of the S3 node pods, narrowing which nodes can mount S3 volumes. The chart adds `kubernetes.io/os: linux` on top of whatever is set here. |
| csi-driver-s3.node.priorityClassName | string | `"system-cluster-critical"` | Priority class of the S3 node pods. |
| csi-driver-s3.node.tolerations | list | `[{"operator":"Exists"}]` | Tolerations of the S3 node pods. The defaults tolerate every taint, so a volume can be mounted on any node the scheduler picks. |
| csi-driver-s3.nodeDriverRegistrar.livenessProbe.enabled | bool | `false` | Leave the node-driver-registrar's own liveness probe off; the node plugin already runs one on its health port. |
| csi-driver-s3.rbac.name | string | `"csi-s3"` | Prefix of the driver's ClusterRole and ClusterRoleBinding names. |
| topograph | object | see the `topograph.*` keys below | [Topograph](https://github.com/NVIDIA/topograph) discovers physical topology and writes its own Kubernetes Node labels. It is disabled until an administrator selects a production provider. |
| topograph.enabled | bool | `false` | Deploy the bundled Topograph chart. Enabled installs require Kubernetes 1.27+, a non-test provider, and Topograph's Kubernetes engine. |
| topograph.provider.name | string | `"test"` | Topograph production provider name, such as `aws`, `dra`, or `infiniband-k8s`. `test` is retained while disabled only because it is the upstream chart default and is rejected on enable. |
| topograph.provider.params | object | `{}` | Provider-specific configuration, including only the credentials or discovery inputs the selected provider documents. |
| topograph.engine.name | string | `"k8s"` | Keep Topograph's Kubernetes engine as the sole publisher of Topograph Node labels. |
| topograph.engine.params | object | `{}` | Kubernetes engine configuration accepted by the pinned Topograph chart. |
| topograph.image.repository | string | `"docker.io/gpustack/mirrored-nvidia-topograph"` | Topograph image repository. Set this to a mirrored repository for air-gapped installs. |
| topograph.image.tag | string | `""` | Topograph image tag. Empty uses the pinned chart application version. |
| topograph.image.pullPolicy | string | `"IfNotPresent"` | Image pull policy for every Topograph workload. |
| topograph.imagePullSecrets | list | `[]` | Pull secrets for the Topograph API server, node observer, and node-data-broker images. |
| topograph.serviceAccount.create | bool | `true` | Create the Topograph API ServiceAccount. Set false with a name when cloud identity is managed outside this release. |
| topograph.serviceAccount.name | string | `""` | Existing Topograph API ServiceAccount name when create is false. |
| topograph.config.credentialsSecret | string | `""` | Existing Secret containing provider credentials, as documented by the selected provider. |
| topograph.securityContext | object | `{"allowPrivilegeEscalation":false,"capabilities":{"drop":["ALL"]},"readOnlyRootFilesystem":true,"runAsNonRoot":true}` | Security context for the Topograph API server. |
| topograph.nodeDataBroker.enabled | bool | `true` | Deploy Topograph's per-node data broker. Provider examples can restrict it without changing the shared API server or node observer placement. |
| topograph.nodeDataBroker.nodeSelector | object | `{}` | Node selector applied only to Topograph's node-data-broker DaemonSet. |
| topograph.nodeDataBroker.securityContext | object | `{"allowPrivilegeEscalation":false,"capabilities":{"drop":["ALL"]},"readOnlyRootFilesystem":true,"runAsNonRoot":true}` | Security context for the node-data-broker container. |

----------------------------------------------
Autogenerated from chart metadata using [helm-docs](https://github.com/norwoodj/helm-docs).
